frappe.pages['utility'].on_page_load = function(wrapper) {
    var page = frappe.ui.make_app_page({
        parent: wrapper,
        title: 'Utility',
        single_column: true
    });

    // Add buttons for backup and migration
    page.add_menu_item('Backup Site', function() {
        backupSite();
    });

    page.add_menu_item('Migrate Site', function() {
        migrateSite();
    });

    // Output container to display results
    const outputDiv = $('<div id="output"></div>').appendTo(page.body);
    
    // Backup Site function
    function backupSite() {
        frappe.call({
            method: "user_utility.user_utility.page.utility.utility.backup_site",
            callback: function(response) {
                if(response.message) {
                    displayMessage(response.message);
                } else if(response.error) {
                    displayMessage(response.error);
                }
            }
        });
    }

    // Migrate Site function
    function migrateSite() {
        frappe.call({
            method: "user_utility.user_utility.page.utility.utility.migrate_site",
            callback: function(response) {
                if(response.message) {
                    displayMessage(response.message);
                } else if(response.error) {
                    displayMessage(response.error);
                }
            }
        });
    }

    // Function to display output messages
    function displayMessage(message) {
        $('#output').html('<pre>' + message + '</pre>');
    }
    
    
    $(frappe.render_template("utility", {})).appendTo(page.body);
}

