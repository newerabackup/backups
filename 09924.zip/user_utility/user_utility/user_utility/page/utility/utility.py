import frappe
import subprocess

# Function to backup the site
@frappe.whitelist()
def backup_site():
    site_name = frappe.local.site
    try:
        command = f"bench --site {site_name} backup"
        result = subprocess.run(command, shell=True, check=True, stdout=subprocess.PIPE, stderr=subprocess.PIPE)
        return {"message": "Backup completed successfully.", "output": result.stdout.decode("utf-8")}
    except subprocess.CalledProcessError as e:
        return {"error": e.stderr.decode("utf-8")}

# Function to migrate the site
@frappe.whitelist()
def migrate_site():
    site_name = frappe.local.site
    try:
        command = f"bench --site {site_name} migrate"
        result = subprocess.run(command, shell=True, check=True, stdout=subprocess.PIPE, stderr=subprocess.PIPE)
        return {"message": "Migration completed successfully.", "output": result.stdout.decode("utf-8")}
    except subprocess.CalledProcessError as e:
        return {"error": e.stderr.decode("utf-8")}

