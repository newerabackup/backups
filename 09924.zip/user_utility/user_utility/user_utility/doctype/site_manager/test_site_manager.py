# Copyright (c) 2024, umar and Contributors
# See license.txt

# import frappe
from frappe.tests.utils import FrappeTestCase


class TestSiteManager(FrappeTestCase):
	pass
